import React from "react";

const TimeLine = () => {
  return <div>TimeLine</div>;
};

export default TimeLine;
